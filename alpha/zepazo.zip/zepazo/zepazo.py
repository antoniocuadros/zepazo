# conda activate video  
# conda install -c conda-forge pydub
# conda install -c conda-forge opencv=4.1.0
#conda install -c conda-forge pysoundfile

import cv2
import numpy as np
import argparse
from functions import *
import threading

print("")
print("   Z.E.P.A.Z.O. 1.00α (05/12/2019)")
print("       © Zerjillo (La Azotea)")
print("")

#print(cv2.ocl.haveOpenCL())
#cv2.ocl.setUseOpenCL(True)

#print(cv2.ocl.useOpenCL())



#print (cv2.getBuildInformation())

parser = argparse.ArgumentParser()
parser.add_argument("video", help="video file to analize")
parser.add_argument("-l", "--limit", type=int, default=50, help="detection limit (1-255) Default 50")
parser.add_argument("-d", "--dilate", type=int, default=1, help="dilate previous images to avoid clear parts of the moon due to movement (odd number)")
parser.add_argument("-sf", "--startFrame", type=int, default=0, help="start frame")
parser.add_argument("-ef", "--endFrame", type=int, default=-1, help="end frame (-1 for last frame)")
parser.add_argument("--stop", help="stop and show image when found", action="store_true")
parser.add_argument("--ignoreAudio", help="do not parse audio track", action="store_true")
parser.add_argument("-ssf", "--saveSurroundingFrames", type=int, default=0, help="save n frames before and after each detection")
parser.add_argument("-t", "--threads", type=int, default=1, help="Number of threads (default 1)")


args = parser.parse_args()

if args.limit < 1 or args.limit > 255:
  parser.error("Limit off bounds [1, 255]")
  

if args.dilate < 1 or args.dilate % 2 != 1:
  parser.error("Dilate must be odd")
  
if args.startFrame < 0:
  parser.error("Start frame must be >= 0")
  
if args.endFrame < -1:
  parser.error("End frame must be >= -1")
    
if args.threads < 1:
  parser.error("Threads must be >= 1")
    
videoParser = VideoParser(args.video, args.dilate, args.limit)
    
if not args.ignoreAudio:
  print("Extracting audio track")
  audioFile = extractAudioFromVideo(args.video)

  audioParser = BeepsParser(audioFile)
  
  beeps = audioParser.findBeeps()
else:
  beeps = []
  
  date = videoParser.datetime
  
  timestamp = datetime.strptime(date, "%Y-%m-%dT%H:%M:%S.%fZ").timestamp()
  l = datetime.fromtimestamp(timestamp).strftime("%d/%m/%y %H:%M:%S.%f UTC")

  
  beeps.append({"fileTime":0, "timePercentage":0, "GPSTimestamp": timestamp, "GPSDateTime": l, "GPSReading":"-"})
  
  timestamp += videoParser.duration
  l = datetime.fromtimestamp(timestamp).strftime("%d/%m/%y %H:%M:%S.%f UTC")
  
  beeps.append({"fileTime":videoParser.duration, "timePercentage":1.0, "GPSTimestamp": timestamp, "GPSDateTime": l, "GPSReading":"-"})
  
  
def worker(videoParser, stop, initFrame, endFrame):
  frames = videoParser.analyze(stop, initFrame, endFrame)
  
  print(frames)
  

  if args.saveSurroundingFrames > 0:
    print("\nSaving surrounding frames")
    for f in frames:
      saveFrames(args.video, f["frameNumber"], args.saveSurroundingFrames) 
      


  print("\nComputing GPS time for found frames\n")

  myfile = open(args.video + "_" + str(initFrame) + "_" + str(endFrame) + ".csv", 'w')
  myfile.write("\"Video File\",\"Frame\",\"GPS Timestamp\",\"GPS Time\"\n") 
  
  for f in frames:
    #print("Frame: %d %f" % (f["frameNumber"], f["timePercentage"]))
    
    # Loook for nearest timestamps in audio file
    t1 = 0
    dist1 = 10000000000.0
    t2 = 0
    dist2 = 10000000000.0

    for b in beeps:
      dist = abs(b["timePercentage"] - f["timePercentage"])
      
      if dist < dist1 and dist < dist2:
        dist2 = dist1
        t2 = t1
        dist1 = dist
        t1 = b
      elif dist < dist2:
        dist2 = dist
        t2 = b
        
    #print(str(t1) + " " + str(t2) + " ")
    
    t = (f['timePercentage'] - t1['timePercentage']) * (t2['GPSTimestamp'] - t1['GPSTimestamp']) / (t2['timePercentage'] - t1['timePercentage']) + t1['GPSTimestamp']
    
    timestring = datetime.fromtimestamp(t).strftime("%d/%m/%y %H:%M:%S.%f UTC")
    print("Frame %d: %f (%s)" % (f["frameNumber"], t, timestring))
    
    myfile.write(args.video + "," + str(f["frameNumber"]) + "," + str(t) + "," + str(timestring) + "\n")
    
  myfile.close()
  
  print("")
  
  
  
  
  
threads = list()
for i in range(args.threads):
  videoParser = VideoParser(args.video, args.dilate, args.limit)
  
  print(videoParser.datetime)

  if args.endFrame == -1:
    args.endFrame = videoParser.totalFrames
    
  framesPerThread = int((args.endFrame - args.startFrame)/args.threads)
  
  f1 = args.startFrame + i * framesPerThread
  f2 = f1 + framesPerThread + 1
  
  if i == args.threads - 1:
    f2 = args.endFrame
   
  print("%d - %d" % (f1, f2))
  
  t = threading.Thread(target=worker, args=(videoParser, args.stop, f1, f2))
  threads.append(t)
  t.start()

#videoParser = VideoParser(args.video, args.dilate, args.limit)
#frames = videoParser.analyze(args.stop, args.startFrame, args.endFrame)

exit()
print("\n")

print(frames)


if args.saveSurroundingFrames > 0:
  print("\nSaving surrounding frames")
  for f in frames:
    saveFrames(args.video, f["frameNumber"], args.saveSurroundingFrames) 
    

if not args.ignoreAudio:
  print("\nComputing GPS time for found frames\n")

  myfile = open(args.video + "_" +  + ".csv", 'w')
  myfile.write("\"\"", "\"Frame\",\"GPS Timestamp\",\"GPS Time\"\n") 
  
  for f in frames:
    #print("Frame: %d %f" % (f["frameNumber"], f["timePercentage"]))
    
    # Loook for nearest timestamps in audio file
    t1 = 0
    dist1 = 10000000000.0
    t2 = 0
    dist2 = 10000000000.0

    for b in beeps:
      dist = abs(b["timePercentage"] - f["timePercentage"])
      
      if dist < dist1 and dist < dist2:
        dist2 = dist1
        t2 = t1
        dist1 = dist
        t1 = b
      elif dist < dist2:
        dist2 = dist
        t2 = b
        
    #print(str(t1) + " " + str(t2) + " ")
    
    t = (f['timePercentage'] - t1['timePercentage']) * (t2['GPSTimestamp'] - t1['GPSTimestamp']) / (t2['timePercentage'] - t1['timePercentage']) + t1['GPSTimestamp']
    
    timestring = datetime.fromtimestamp(t).strftime("%d/%m/%y %H:%M:%S.%f UTC")
    print("Frame %d: %f (%s)" % (f["frameNumber"], t, timestring))
    
    myfile.write(args.video + "," + str(f["frameNumber"]) + "," + str(t) + "," + str(timestring) + "\n")
    
  myfile.close()
  
  print("")
