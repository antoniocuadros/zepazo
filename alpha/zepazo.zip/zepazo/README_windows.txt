In order to get ZEPAZO working we must first install and configure some dependencies (mainly the Python language interpreter and some libraries). We are going to use Anaconda (a Python package manager) to ease the process. In:

https://www.anaconda.com/distribution/

we download the 3.8 verion for Windows (64bit x86) (Anaconda3-2020.07-Windows-x86_64.exe)

Once downloaded we run the Anaconda installer and we use the default settings (next, next, yes, next, of course yes, damn it yes!, continue, I accept, yes, yes, I understand, sure and so on...)

We unzip Zepazo in a folder. There should appear a pair of .py files (which is Zepazo itself).

We open the "Anaconda Prompt" (Start button -> Anaconda 3 -> Anaconda Prompt)

We surf to where we have unzipped Zepazo:

> cd folder/zepazo

There we are going to create a virtual environment with the Python version that we are going to use:

> conda create -n zepazo python=3.7

(if there is some error due to the Python version we can try "python=3.8")

We activate the environment:

> conda activate zepazo

We install some libraries:

> conda install -c conda-forge opencv=4.1.0
> conda install -c conda-forge pydub
> conda install -c conda-forge ffmpeg-python

And now we can run Zepazo with:

> python zepazo.py --ignoreAudio -ssf 1 -d 13 -l 90 PATH_TO_YOUR_VIDEO

Explanation of some of the parameters:

+ --ignoreAudio: To avoid trying to process beeps of the  GPS (work in progress).
+ -ssf 1: Saves the previous and next frame for each detected impact.
+ -d 13: Dilates the previous image by 13 pixels. This avoids problems with sudden movements of the camera and avoids the detection of the timestamps if they are in the frame. This parameter can be adjusted in case that the video suffers of a greater shaking.
+ -l 90: The limit detection. Lower limit makes zepazo more sensitive but a larger number of false positives may appear.
+ -h Shows the rest of the parameters and options.






