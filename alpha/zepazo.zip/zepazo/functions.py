import tempfile
import os
import subprocess
#import soundfile as sf
import math
import numpy as np
import cv2
from datetime import datetime
import sys
import time
import ffmpeg


def saveFrames(videoPath, frame, n):
  init = frame - n
  end = frame + n
  
  folderPath = videoPath + "_" + str(frame).zfill(6)
  
  try:
    os.mkdir(folderPath)
  except OSError as exc:
    print (exc)
    
  vidcap = cv2.VideoCapture(videoPath)

  count = init
  vidcap.set(cv2.CAP_PROP_POS_FRAMES, init)

  while count<=end:
    success,image = vidcap.read()
    
    cv2.imwrite(folderPath + "/" + str(count).zfill(6) + ".png", image)
    
    count+=1
  

class VideoParser:
  kernelSize = 1
  kernel = None
  limit = 1
  videoPath = None
  vidcap = None
  currentFrame = 0
  totalFrames = 0
  fps = 0
  width = 0
  height = 0
  endFrame = -1
  datetime = None
  duration = 0

  
  def __init__(self, videoPath, dilateSize, limit):
    self.videoPath = videoPath
    self.vidcap = cv2.VideoCapture(self.videoPath)
    
    self.kernelSize = dilateSize
    self.kernel = np.ones((self.kernelSize, self.kernelSize), dtype=np.float32)
    self.limit = limit

    
    self.totalFrames = int(self.vidcap.get(cv2.CAP_PROP_FRAME_COUNT))
      
    self.fps    = self.vidcap.get(5)
    self.width  = int(self.vidcap.get(3))  
    self.height = int(self.vidcap.get(4)) 
    print("")
    print("Length of video: %d frames" % self.totalFrames)
    print("FPS: %.3f fps" % self.fps)
    print("Width: %d pixels " % self.width)
    print("Height: %d pixels" % self.height)
    
    try: 
      self.datetime = ffmpeg.probe(videoPath)['format']['tags']['creation_time']
    except:
      self.datetime = "2020-01-01T00:00:00.0000Z"
      
    self.duration = float(self.totalFrames) / float(self.fps)
    
  def analyze(self, stop, startFrame=0, endFrame=-1):
    self.currentFrame = startFrame
    
    if self.currentFrame < 0:
      self.currentFrame = 0
    
    if (endFrame > -1):
      self.endFrame = endFrame
    else:
      self.endFrame = self.totalFrames
        
    initTime = time.time()
    initFrame = self.currentFrame
    
    self.vidcap.set(cv2.CAP_PROP_POS_FRAMES, self.currentFrame)
    
    framesFound = []
    
    success, image = self.vidcap.read()
    
    hsvimg = cv2.cvtColor(image, cv2.COLOR_BGR2HSV) # Just to reserve memory
    
    newFrame = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # Just to reserve memory
    difference = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # Just to reserve memory

    r = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # Just to reserve memory
    g = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # Just to reserve memory
    b = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # Just to reserve memory

    
    lastFrame = None

    while success:      
      #gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
      
      # print(image)
      
      #gray = np.amax(image, axis = 2)
      
      
      #cv2.cvtColor(image, cv2.COLOR_BGR2HSV, dst=hsvimg)
      
      #cv2.split(image, (h, s, newFrame))
      
      #newFrame[:,:] = hsvimg[:,:,2]
      
      #newFrame = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
      
      cv2.split(image, (r, g, b))
      cv2.max(r,cv2.max(g,b,dst=newFrame), dst=newFrame)
      #print(gray)
      
      #exit(0)
      
     # cv2.imshow("Gray", s)
     # cv2.waitKey(1000000)
      
     # print(len(gray))
      
     # print(v)
      
     # exit(0)
      #newFrame = gray#np.array(gray, dtype=np.float32)
        
      if lastFrame is not None:
        currentTime = time.time()
        elapsedTime = currentTime - initTime
        completed = (self.currentFrame - initFrame)/(self.endFrame - initFrame)
        toBeCompleted = 1.0 - completed
        timeToCompletion = toBeCompleted * elapsedTime / completed
        timeToCompletionText = str(int(timeToCompletion / 60.0)).zfill(2) + ":" + str(int(timeToCompletion % 60.0)).zfill(2)
        sys.stdout.write("\rFrame: %d (%.2f%%) Time left: %s   " % (self.currentFrame, 100*completed, timeToCompletionText))
        sys.stdout.flush()
        
      
        difference = cv2.subtract(newFrame, lastFrame, dst=difference) 
        
        #(min, max, minL, maxL) = cv2.minMaxLoc(difference)
        
        max = np.amax(difference[int(self.kernelSize/2):int(self.height-self.kernelSize/2), int(self.kernelSize/2):int(self.width-self.kernelSize/2)])
    
        if max > self.limit:
          print("  Detected frame %d, Max: %.2f" % (self.currentFrame, max))
          
          framesFound.append({"frameNumber":self.currentFrame, "timePercentage":self.currentFrame/self.totalFrames})
          
          #difference[difference < 0.0] = 0.0
          
          ret, threshed_img = cv2.threshold(np.array(difference, dtype=np.uint8), self.limit, 255, cv2.THRESH_BINARY)
          contours, hier = cv2.findContours(threshed_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
          
          for c in contours:
            x, y, w, h = cv2.boundingRect(c)
            cv2.rectangle(image, (x-10, y-10), (x+w+10, y+h+10), (0, 0, 255), 2)
            
          cv2.imwrite(self.videoPath + "_" + str(self.currentFrame).zfill(6) + ".png", image)
          
          
          if (stop):
            print("LALA")
            #cv2.namedWindow('Gray',cv2.WINDOW_NORMAL)
            #cv2.namedWindow('Difference',cv2.WINDOW_NORMAL)
            #cv2.namedWindow('Previous Frame',cv2.WINDOW_NORMAL)

            #print("LOLO")
            #cv2.imshow("Gray", image)
            #cv2.imwrite(self.videoPath + "_" + str(self.currentFrame).zfill(6) + "_GRAY.png", image)
            
            #difference = ((difference - difference.min()) / (difference.max() - difference.min()))*255
            #diffShow = np.array(difference, dtype=np.uint8)
            #cv2.imshow("Difference", diffShow)
            #cv2.imwrite(self.videoPath + "_" + str(self.currentFrame).zfill(6) + "_DIFFERENCE.png", diffShow)
            
            #aveShow = np.array(lastFrame, dtype=np.uint8)
            #cv2.imshow("Previous Frame", aveShow)
            #cv2.imwrite(self.videoPath + "_" + str(self.currentFrame).zfill(6) + "_PREVIOUS.png", aveShow)
                        
            #cv2.waitKey(1000000)
      else:
        lastFrame = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # To reserve memory for the first previous frame
    
      lastFrame = cv2.dilate(newFrame, self.kernel,iterations = 1, dst=lastFrame)
    
      self.currentFrame += 1
      
      success, image = self.vidcap.read(image)
      
      if (self.currentFrame > self.endFrame):
        success = False
      
    print("")
    
    return framesFound
      



      
# DE AQUI EN ADELANTE ES PARA EL TEMA DEL SONIDO CON GPS
      
def extractAudioFromVideo(videoPath):
  path, ext = os.path.splitext(videoPath)
  
  audioFile = path + ".wav"
  
  #print(audioFile)
  
  ffmpegCommand = ["ffmpeg", "-i", videoPath, "-ac", "1", "-ar", "44100", "-loglevel", "quiet", audioFile]
  
  subprocess.call(ffmpegCommand)
  
  return audioFile 



def goertzel(samples, sample_rate, *freqs):
    """
    Implementation of the Goertzel algorithm, useful for calculating individual
    terms of a discrete Fourier transform.
    `samples` is a windowed one-dimensional signal originally sampled at `sample_rate`.
    The function returns 2 arrays, one containing the actual frequencies calculated,
    the second the coefficients `(real part, imag part, power)` for each of those frequencies.
    For simple spectral analysis, the power is usually enough.
    Example of usage :
        
        freqs, results = goertzel(some_samples, 44100, (400, 500), (1000, 1100))
    """
    window_size = len(samples)
    f_step = sample_rate / float(window_size)
    f_step_normalized = 1.0 / window_size

    # Calculate all the DFT bins we have to compute to include frequencies
    # in `freqs`.
    bins = set()
    for f_range in freqs:
        f_start, f_end = f_range
        k_start = int(math.floor(f_start / f_step))
        k_end = int(math.ceil(f_end / f_step))

        if k_end > window_size - 1: raise ValueError('frequency out of range %s' % k_end)
        bins = bins.union(range(k_start, k_end))

    # For all the bins, calculate the DFT term
    n_range = range(0, window_size)
    freqs = []
    results = []
    for k in bins:

        # Bin frequency and coefficients for the computation
        f = k * f_step_normalized
        w_real = 2.0 * math.cos(2.0 * math.pi * f)
        w_imag = math.sin(2.0 * math.pi * f)

        # Doing the calculation on the whole sample
        d1, d2 = 0.0, 0.0
        for n in n_range:
            y  = samples[n] + w_real * d1 - d2
            d2, d1 = d1, y

        # Storing results `(real part, imag part, power)`
        results.append((
            0.5 * w_real * d1 - d2, w_imag * d1,
            d2**2 + d1**2 - w_real * d1 * d2)
        )
        freqs.append(f * sample_rate)
    return freqs, results





class BeepsParser:
  frequencies = [440, 540, 640, 740, 840, 940, 1040, 1140, 1240, 1340]
  characters = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
  beepsDuration = 0.1
  searchFreq = 440
  frequenciesIntervals = [None] * len(frequencies)
  totalAudioFrames = 0
  sampleRate = 0
  audioLength = 0
  chunkReadSize = 0
  windowSize = 0
  audioFile = None

  def __init__(self, audioFile):
    self.audioFile = audioFile
    
    # Create frequency intervals used for goertzel    
    for n in range(0, len(self.frequencies)):
      self.frequenciesIntervals[n] = (self.frequencies[n] - 1, self.frequencies[n] + 1)
    
    info = sf.info(audioFile, True)
  
    self.totalAudioFrames = info.frames
    self.sampleRate = info.samplerate
    self.audioLength = self.totalAudioFrames / self.sampleRate

    print("")
    print("Total audio frames: %d" % self.totalAudioFrames)
    print("Audio sample rate: %d" % self.sampleRate)
    print("Audio length: %.03f seconds" % self.audioLength)
    
    self.chunkReadSize = 60 * self.sampleRate
    
    self.windowSize = int(self.sampleRate * self.beepsDuration)
    
  def findBeeps(self):
    beeps = []
    currentParsingTime = 0
    currentChunkStartingTime = 0
    currentChunkSize = 0
    
    print("Looking for beeps...")
    
    while currentParsingTime < self.totalAudioFrames - 2 * self.sampleRate:
      if (currentParsingTime > currentChunkStartingTime + currentChunkSize - 2 * self.sampleRate):
        print("Reading chunk starting at %d" % currentParsingTime)
        datos = sf.read(self.audioFile, frames=self.chunkReadSize, start=currentParsingTime)
        datos = datos[0]
        currentChunkSize = len(datos)
        currentChunkStartingTime = currentParsingTime
    
      currentChunkParsingTime = currentParsingTime - currentChunkStartingTime 
      
      freqs, results = goertzel(datos[int(currentChunkParsingTime):int(currentChunkParsingTime) + int(self.windowSize)], self.sampleRate, (self.searchFreq-1, self.searchFreq+1))
      
      power = np.amax(np.array(results)[:,2])
      
      if (power > 500): # Initiate a fine grained search
        print("Found: " + str(currentParsingTime) + " " + str(power))
        
        maxP = 0
        maxPTime = 0
        
        for newTime in range(currentParsingTime - self.windowSize, currentParsingTime + self.windowSize, int(self.sampleRate/3000)):
          currentChunkParsingTime = newTime - currentChunkStartingTime
          freqs, results = goertzel(datos[int(currentChunkParsingTime):int(currentChunkParsingTime) + int(self.windowSize)], self.sampleRate, (self.searchFreq-1, self.searchFreq+1))
      
          power = np.amax(np.array(results)[:,2])
          
          if power > maxP:
            maxP = power
            maxPTime = newTime
            
        print("   Re-found: " + str(maxPTime) + " " + str(maxPTime / self.sampleRate) + " " + str(maxP) )
        
        currentParsingTime = maxPTime + self.windowSize * 11 # Go fordward a full signal (11 chars)
        
        # Detecting actual beeps
        readed = ""
        for n in range(1,11):
          currentChunkParsingTime = maxPTime - currentChunkStartingTime
          freqs, results = goertzel(datos[int(currentChunkParsingTime) + int(self.windowSize) * n:int(currentChunkParsingTime) + int(self.windowSize) * (n+1)], self.sampleRate, *self.frequenciesIntervals)
        
          powers = np.array(results)[:,2]
        
          #print(i , freqs, powers)

          (selectedFreq, selectedPower) = self.getMaximumFreq(freqs, powers)
        
          #print(int(selectedFreq), selectedPower)
          
          #print(getCharFromFreq(selectedFreq))
          readed = readed + str(self.getCharFromFreq(selectedFreq))
          
        gpsTime = datetime.strptime(readed+"00.0000UTC", "%d%m%y%H%M%S.%f%Z").timestamp()
        
        beeps.append({"fileTime":maxPTime / self.sampleRate, "timePercentage":maxPTime / self.totalAudioFrames, "GPSTimestamp": gpsTime, "GPSDateTime": datetime.fromtimestamp(gpsTime).strftime("%d/%m/%y %H:%M:%S.%f UTC"), "GPSReading":readed})
        print(readed)
        
        currentParsingTime = currentParsingTime + self.sampleRate * 57  #Skip 57 seconds
      else:
        currentParsingTime = currentParsingTime + int(self.windowSize/2) # Go fordward half of a char
      
      
    print("End of file. Beeps found:")
    
    print(beeps)
    
    return beeps
    
  def getMaximumFreq(self, freqs, powers):
    maxPower = 0
    freq = 0
    
    for n in range(0, len(powers)):
      if powers[n] > maxPower:
        maxPower = powers[n]
        freq = freqs[n]
        
    return (freq, maxPower)
    
  def getCharFromFreq(self, freq):
    for n in range(0, len(self.frequencies)):
      if int(self.frequencies[n]) == int(freq):
        return self.characters[n]
    
    return None
